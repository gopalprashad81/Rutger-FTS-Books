par(mfrow=c(2,2))
plot(hsales,xlab="Year",ylab="Monthly housing sales (millions)")
plot(ustreas,xlab="Day",ylab="US treasury bill contracts")
plot(elec,xlab="Year",ylab="Australian monthly electricity production")
plot(diff(dj),xlab="Day",ylab="Daily change in Dow Jones index")

par(mfrow=c(1,1))
fit <- stl(elecequip, s.window=5)
plot(elecequip, col="gray",
     main="Electrical equipment manufacturing",
     ylab="New orders index", xlab="")
lines(fit$time.series[,2],col="red",ylab="Trend")

plot(fit)

plot(elecequip, col="grey",
     main="Electrical equipment manufacturing",
     xlab="", ylab="New orders index")
lines(seasadj(fit),col="red",ylab="Seasonally adjusted")

## alternatively you can use the following

plot(elecequip, col="gray",
     main="Electrical equipment manufacturing",
     ylab="New orders index", xlab="")
lines(elecequip-fit$time.series[,1],col="red",ylab="Trend")

## STL with unchanged seasonal component. Check the options.
fit <- stl(elecequip, t.window=15, s.window="periodic", robust=TRUE)
plot(fit)

## Compare with the case when seasonal component changes.
fit <- stl(elecequip, s.window=5)
plot(fit)

##
fit <- stl(elecequip, t.window=15, s.window="periodic", robust=TRUE)
eeadj <- seasadj(fit)
plot(naive(eeadj), xlab="New orders index",
     main="Naive forecasts of seasonally adjusted data")
##
fcast <- forecast(fit)
plot(fcast, ylab="New orders index")

## For MA, if centre=TRUE, then it corresponds to MA of MA. See the following 
## examples.
beer2 <- window(ausbeer,start=1992)
ma4 <- ma(beer2, order=4, centre=FALSE)
ma2x4 <- ma(beer2, order=4, centre=TRUE)

plot(elecequip, ylab="New orders index", col="gray",
     main="Electrical equipment manufacturing (Euro area)")
lines(ma(elecequip, order=12), col="red")



################## simple exponential smoothing ##################

rain= scan("http://robjhyndman.com/tsdldata/hurst/precip1.dat",skip=1)
#rain= scan("precip1.dat",skip=1)
rainseries <- ts(rain,start=c(1813))

## Plot the original series, what do you see?
plot.ts(rainseries)
plot.ts(rain)
## Simple exponential smoothing. Please do ?HoltWinters
rainseriesforecasts <- HoltWinters(rainseries, beta=FALSE, gamma=FALSE)
## The output is a list, which contains a few objects. Check the following
rainseriesforecasts
rainseriesforecasts$alpha
rainseriesforecasts$coefficients
rainseriesforecasts$fitted
plot(rainseriesforecasts$fitted)
plot(rainseriesforecasts)
rainseriesforecasts$SSE

## We can assign initial values for the level using l.start
HoltWinters(rainseries, beta=FALSE, gamma=FALSE, l.start=23.56)

rainseriesforecasts2 <- forecast(rainseriesforecasts, h=8)
#plot.forecast(rainseriesforecasts2)
plot(rainseriesforecasts2)
# Now checking the ACF of the residuals.

acf(rainseriesforecasts2$residuals, lag.max=20, na.action=na.omit)

# to formally test the existence or non existence of autocorrelation, we do
Box.test(rainseriesforecasts2$residuals, lag=20, type="Ljung-Box")

####################### Holt's exponential smoothing.

skirts <- scan("http://robjhyndman.com/tsdldata/roberts/skirts.dat",skip=5)
skirtsseries <- ts(skirts,start=c(1866))
plot.ts(skirtsseries)

##### Now do similar things are in simple exponential smoothing.

skirtsseriesforecasts = HoltWinters(skirtsseries, gamma=FALSE)
skirtsseriesforecasts

# Plot the fitted values

plot(skirtsseriesforecasts)

# Now look at the forecast 

skirtsseriesforecasts2 <- forecast(skirtsseriesforecasts, h=8)
plot(skirtsseriesforecasts2)

# Check the residuals

acf(skirtsseriesforecasts2$residuals, lag.max=20)
acf(skirtsseriesforecasts2$residuals, lag.max=20,na.action=na.omit)
Box.test(skirtsseriesforecasts2$residuals, lag=20, type="Ljung-Box")


##################### Holt and Winters smoothing.

#souvenir <- scan("http://robjhyndman.com/tsdldata/data/fancy.dat")
#souvenirtimeseries <- ts(souvenir, frequency=12, start=c(1987,1))
souvenirtimeseries <- ts(fancy, frequency=12, start=c(1987,1))
plot(souvenirtimeseries)

souvenirtimeseries <- ts(fancy, frequency=12, start=c(1987,6))
## Perform log transformation.

logsouvenirtimeseries <- log(souvenirtimeseries)

plot(logsouvenirtimeseries)

## Holt-winters smoothing. 

souvenirtimeseriesforecasts <- HoltWinters(logsouvenirtimeseries)
souvenirtimeseriesforecasts

## Plot the fitted values
plot(souvenirtimeseriesforecasts)

souvenirtimeseriesforecasts2 <- forecast(souvenirtimeseriesforecasts, h=48)
plot(souvenirtimeseriesforecasts2)

forecast(souvenirtimeseriesforecasts, h=2)

## Check the residuals
acf(souvenirtimeseriesforecasts2$residuals, lag.max=20,na.action=na.omit)
Box.test(souvenirtimeseriesforecasts2$residuals, lag=20, type="Ljung-Box")

